// $uibModal.open({
//   templateUrl: "modal.html",
//   windowClass: 'center-modal'
// });